<?php
	require_once('app/core/init.php');
	new \app\core\App();