		<ul>
			<li><a href='/Client/index'>Client index</a></li>
			<li><a href='/Client/create'>Client create</a></li>
			<li><a href='/Main/index'>Main index</a></li>
			<li><a href='/User/login'>Log in</a></li>
		</ul>
