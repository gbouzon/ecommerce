<?php
	//TODO: more initialization goes in this file
	session_start();
	require_once('app/core/autoload.php');